package com.example.contactssqliteapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewContactsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contacts);
    }
}